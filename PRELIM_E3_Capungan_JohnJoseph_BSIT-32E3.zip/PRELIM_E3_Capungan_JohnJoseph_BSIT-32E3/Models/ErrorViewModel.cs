namespace PRELIM_E3_Capungan_JohnJoseph_BSIT_32E3.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}